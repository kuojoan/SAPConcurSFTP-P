# SAP Concur SFTP Exchanger Manual

---
### Version

1.6

### Description

This program was created for SAP ECC <--> SAP Concur data exchange.

And transfer SAP Concur SRE file to Excel for EIP.

### Build environment

* #### Python 3.10
  * paramiko
  * pyinstaller
  * python-gnupg
  * openpyxl
* #### gnupg-w32cli-1.4.x.exe
* #### gnupg-w32-2.3.2_20210824
  * url : https://gnupg.readthedocs.io/en/latest/
* #### PyCharm 2021.2.2
* #### Visual Studio Installer
  * Visual Studio Community 2019
    * C++ Desktop Development
      * MSVC v142 - VS 2019 C++ x64/x86 build tools
      * MSVC v141 - VS 2017 C++ x64/x86 build tools
      * MSVC v140 - VS 2015 C++ build tools (v14.00)

### Run configuration

* #### interpreter options :
  * -m PyInstaller --onefile --clean --add-data "config.ini;." --add-data "in;in" --add-data "out;out" --add-data "in_tmp;in_tmp" --add-data "out_tmp;out_tmp" --add-data "logs;logs" --add-data "key;key"

### Run environment

* #### config.ini
  * modify **[DOWNLOAD_PATHS]** to specific folder for each file types in environment.
    * SAE
    * PRAE
    * SRE

* #### gnupg-w32-2.3.2_20210824
  * url : https://gnupg.readthedocs.io/en/latest/
* #### files & folders structure :
  * SAPConcurSFTPin.exe
  * SAPConcurSFTPout.exe
  * SAPConcurSRE2Excel.exe
  * config.ini
  * key
    * xxx.asc
    * xxx.ppk
  * out
    * PRAE
      * Complete
      * Download
      * Error
    * SAE
      * Complete
      * Download
      * Error
    * SRE
      * Complete
      * Download
      * Error
      * Export
  * out_tmp
  * in
  * in_tmp
  * logs

* #### Synology NAS (linux)
  * Environment
    * python3 -m ensurepip.
    * python3 -m pip install --upgrade pip
    * python3 -m pip install paramiko
    * python3 -m pip install python-gnupg
    * python3 -m pip install openpyxl
  * Daily Tasks
    * 5:50 am : SAPConcurSFTPin
    * 6:00 am : SAPConcurSFTPout
    * 7:40 am : SAPConcurSRE2Excel