#!/usr/bin/python
# coding=UTF-8
# PGPKeyGenerator.py                #
# PGP key Generator for Concur SFTP #
# Create by 2021.09.30              #
# Author : James Hsiao              #
#####################################

import gnupg
import os
import os.path

print('KeyGen Preparing...')
gpg_bin = r'C:\Program Files (x86)\gnupg\bin\gpg'

gpg = gnupg.GPG(gpgbinary=gpg_bin)
gpg.encoding = 'utf-8'

print('KeyGen Starting...')

key_input_data = gpg.gen_key_input(
    name_real = 'MitutoyoTW',
    name_email = 'jameshsiao@mitutoyo.com.tw',
    expire_date = 0,
    key_type = 'RSA',
    key_length = 2048,
    key_usage = '',
    subkey_type = 'RSA',
    subkey_length = 2048,
    subkey_usage = 'encrypt,sign',
    passphrase = 'mitutoyotw'
)

key = gpg.gen_key(key_input_data)

print(key)
print('KeyGen Finished.')

if (key.fingerprint is not None):
    # Create ASCII-readable versions of public / secret keys
    print('Create ASCII Key Starting...')
    ascii_armored_public_keys = gpg.export_keys(key.fingerprint)
    ascii_armored_secret_keys = gpg.export_keys(
        keyids = key.fingerprint,
        secret = True,
        passphrase = 'mitutoyotw'
    )
    print('Create ASCII Key Finished.')

    # export
    print('Export Key Starting...')
    with open('key\MTW-ConcurPGPPubkey.asc', 'w') as f:
        f.write(ascii_armored_public_keys)
    with open('key\MTW-ConcurPGPSeckey.asc', 'w') as f:
        f.write(ascii_armored_secret_keys)
    print('Export Key Finished.')