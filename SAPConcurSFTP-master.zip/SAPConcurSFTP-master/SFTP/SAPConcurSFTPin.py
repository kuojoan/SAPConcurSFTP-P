#!/usr/bin/python
# coding=UTF-8
# SAPConcurSFTPin.py                #
# SAP ERP --> SAP Concur SFTP in    #
# Create by 2021.10.05              #
# Author : James Hsiao              #
#####################################
import datetime
import gnupg
import paramiko
import configparser
import os
import os.path

config = configparser.ConfigParser()
config.read('config.ini')

host = config['SFTP']['host']
port = config['SFTP']['port']
user = config['SFTP']['user']
privKey = paramiko.RSAKey.from_private_key_file(config['SFTP']['privKey'],config['SFTP']['passphrase'])
gpg_bin = config['PGP']['gpg_bin']
pppseckey = config['PGP']['pppseckey']
localinencyptpath = config['PATHS']['local_in_tmp']
localinpath = config['PATHS']['local_in_path']
logpath = config['PATHS']['log_path']
remoteinpath = config['PATHS']['remote_in_path']

def connect_concur(logfile, hostname, port, username, pkey, passphrase):
    try:
        conn = paramiko.SSHClient()
        conn.set_missing_host_key_policy(paramiko.AutoAddPolicy)
        conn.connect(hostname=hostname, port=port, username=username, pkey=pkey, allow_agent=True, disabled_algorithms=dict(pubkeys=['rsa-sha2-256', 'rsa-sha2-512']))
        logfile.write('SAP Concur SFTP connected.\n')
        return conn
    except Exception as e:
        logfile.write('Connect unexpected error :'+ str(e) +'\n')

def disconnect_concur(logfile, conn):
    try:
        conn.close()
        logfile.write('SAP Concur SFTP closed.\n')
    except Exception as e:
        logfile.write('Disconnect unexpected error :'+ str(e) + '\n')

def put_concur_file(logfile, conn, file):
    trans = paramiko.SFTPClient.from_transport(conn.get_transport())
    remotefile = '/'+remoteinpath+'/'+file
    localfile = localinencyptpath+file
    result = trans.put(localfile, remotefile)
    logfile.write('put file : ' + str(remotefile) +'\n')
    os.remove(localfile)

def gpg_load_key():
    gpg = gnupg.GPG(gpgbinary=gpg_bin)
    gpg.encoding = 'utf-8'
    seckey = open(pppseckey).read()
    result = gpg.import_keys(seckey)
    return gpg

def gpg_encrypt_files(gpg, inpath, encyptpath):
    results = {}
    for i in os.listdir(inpath):
        with open(inpath+i, 'rb') as f:
            encyptfile = i+'.pgp'
            status = gpg.encrypt_file(f, recipients=['jameshsiao@mitutoyo.com.tw'], output=encyptpath+encyptfile, always_trust=True)
            results[(encyptfile)] = status.status
            logfile.write('encypted : ' + str(results) + '\n')
        if results[((encyptfile))] == 'encryption ok':
            os.remove(inpath+i)
    return results

if True:
    # sftp -o IdentityFile=MTW-ConcurSSHRSAPrivkey.ppk p0021113gdod@mft-us.concursolutions.com

    # write logs
    logfile = open(logpath+'logs_'+ str(datetime.date.today())+'.txt', 'a')
    logfile.write('=== SFTP in === \n')

    logfile.write('SAP Concur SFTP start :' + str(datetime.datetime.now()) + '\n')

    gpg = gpg_load_key()
    #Encrypt files
    results = gpg_encrypt_files(gpg, localinpath, localinencyptpath)
    #Connect Concur SFTP
    conn = connect_concur(logfile, host, port, user, privKey, None)
    i = 1
    for key, result in results.items():
        print(key)
        put_concur_file(logfile, conn, key)
    #Disconnect Concur SFTP
    disconnect_concur(logfile, conn)

    logfile.write('SAP Concur SFTP end :' + str(datetime.datetime.now()) + '\n\n')
    logfile.close()