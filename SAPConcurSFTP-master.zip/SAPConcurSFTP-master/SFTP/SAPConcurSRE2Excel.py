#!/usr/bin/python
# coding=UTF-8
# SAPConcurSRE2Excel.py             #
# SAP Concur SRE file --> Excel File#
# Create by 2021.12.17              #
# Author : James Hsiao              #
#####################################
import datetime
import configparser
import os
import os.path
import csv
import smtplib
import math
from os.path import basename
from openpyxl import load_workbook
from openpyxl import Workbook
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import COMMASPACE, formatdate
from datetime import datetime as DT

config = configparser.ConfigParser()
config.read('config.ini',encoding='utf-8')
logpath = config['PATHS']['log_path']
sreexportpath = config['SRE2EXCEL']['SRE_Export_path']
srecompletepath = config['SRE2EXCEL']['SRE_Complete_path']
sredownloadpath = config['DOWNLOAD_PATHS']['SRE_Download_path']
mailserver = config['SRE2EXCEL']['MAILSERVER']
mailsender = config['SRE2EXCEL']['SENDER']
mailreceiver = config['SRE2EXCEL']['RECEIVER']

def read_csv_files(file):
    rows = []
    with open(file, newline='', encoding='utf-8') as f:
        csv_rows = csv.reader(f, delimiter='|')
        rows = list(csv_rows)
    return rows

def write_excel_file(head, data):
    filename = 'EIP出差資料' + head[1] + '.xlsx'
    print(filename)
    wb = Workbook()
    sheet = wb.active
    sheet.title = 'PsnContractImport'

    #write titles
    sheet['A1'] = '員編'
    sheet['B1'] = '姓名'
    sheet['C1'] = '組織'
    sheet['D1'] = '開始日期'
    sheet['E1'] = '結束日期'
    sheet['F1'] = '開始時間'
    sheet['G1'] = '結束時間'
    sheet['H1'] = '時數'
    sheet['I1'] = '請假類型'

    #write data
    for row in data:
        sheet.append(row)
    wb.save(os.path.join(sreexportpath, filename))

def calculate_hours(start_date, start_time, end_date, end_time):
    print("calculate_hours : " , start_date, start_time, end_date, end_time)
    start_datetime = DT.strptime(start_date + ' ' +start_time, '%Y-%m-%d %H:%M')
    end_datetime = DT.strptime(end_date + ' ' + end_time, '%Y-%m-%d %H:%M')
    rest_starttime = DT.now()
    rest_endime = DT.now()
    print(start_datetime , end_datetime)
    print((end_datetime - start_datetime))

    days = (end_datetime - start_datetime).days
    hours = 0

    if days <= 0:
        rest_starttime = DT.strptime(start_date + ' ' + '12:00', '%Y-%m-%d %H:%M')
        rest_endime = DT.strptime(end_date + ' ' + '12:59', '%Y-%m-%d %H:%M')
        hours = (end_datetime - start_datetime).seconds / 60 / 60
        if start_datetime < rest_starttime and end_datetime > rest_endime:
            hours = hours - 1
    elif days > 0:
        rest_starttime = DT.strptime(end_date + ' ' + '12:00', '%Y-%m-%d %H:%M')
        rest_endime = DT.strptime(end_date + ' ' + '12:59', '%Y-%m-%d %H:%M')
        start_datetime = DT.strptime(end_date + ' ' + '08:30', '%Y-%m-%d %H:%M')
        hours = (end_datetime - start_datetime).seconds / 60 / 60
        if start_datetime < rest_starttime and end_datetime > rest_endime:
            hours = hours - 1

    if hours > 8:
        hours = 8

    ceil_hours = math.ceil(hours)
    total_hours = (days * 8) + ceil_hours
    return total_hours

def filter_sre_data(rows):
    head = rows[0]
    data = []
    rec = []
    rows.pop(0)
    for row in rows:
        if '*MITUTOYO DOMESTIC REQUEST POLICY' in row or '*MITUTOYO OVERSEAS REQUEST POLICY' in row :
            #rec = [row[4], row[5]+row[6], '', row[44], row[46], row[45], row[47], calculate_hours(str(row[44]), str(row[45]), str(row[46]), str(row[47])), '出差']
            rec = [row[4], '', '', row[44], row[46], row[45], row[47],
                   calculate_hours(str(row[44]), str(row[45]), str(row[46]), str(row[47])), '出差']
            data.append(rec)
    print(data)
    return head, data

def send_mail(send_from, send_to, subject, text, files=None):
    #assert isinstance(mailreceiver, list)
    print(send_to)
    msg = MIMEMultipart()
    msg['From'] = send_from
    msg['To'] = COMMASPACE.join(send_to)
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = subject

    msg.attach(MIMEText(text))

    for f in files or []:
        with open(f, 'rb') as fil:
            part = MIMEApplication(fil.read(), Name=basename(f))
        #After the file is closed
        part['Content-Disposition'] = 'attachment; filename="%s"' % basename(f)
        msg.attach(part)

    result = 0
    try:
        smtp = smtplib.SMTP(mailserver)
        smtp.sendmail(send_from, send_to, msg.as_string())
        smtp.close()
    except Exception as e:
        logfile.write('Send email error :'+ str(e) +'\n')
        result = 1
    return result

def move_sre_excel(src, dst):
    try:
        logfile.write('move file from :' + src + ' to ' + dst + '\n')
        os.rename(src, dst)
    except Exception as e:
        logfile.write('remove file error :' + str(e) + '\n')

if True:
    excel_list = []
    subject = ''
    msgtext = ''
    result = 0

    # write logs
    logfile = open(logpath+'logs_'+ str(datetime.date.today())+'.txt', 'a', encoding='utf-8')
    logfile.write('=== Transfer SRE to excel : ' + str(datetime.datetime.now()) + '\n\n')

    #read SRE file to list
    for i in os.listdir(sredownloadpath):
        tmp_rows = []
        sre_rows = []
        tmp_rows = read_csv_files(os.path.join(sredownloadpath, i))
        sre_rows.extend(tmp_rows)

        #write SRE data to Excel
        head, data = filter_sre_data(sre_rows)
        if(len(data) > 0):
            write_excel_file(head, data)

    #Prepare email content
    for i in os.listdir(sreexportpath):
        subject = '[SAP Concur] SRE to EIP daily excel file : ' + i
        msgtext = 'Attachment is the SRE to EIP daily excel file : "' + i + '"\n\nThis mail was sent by SAPConcurSRE2Excel Program automatically.'
        excel_list.append(os.path.join(sreexportpath, i))

    logfile.write('SRE to excel list : ' + str(excel_list) + '\n\n')
    logfile.write('Send SRE to excel email : ' + str(datetime.datetime.now()) + '\n\n')

    # Send email with attachemnt
    result = 0
    if len(excel_list) > 0 :
        result = send_mail(mailsender, mailreceiver.split(','), subject, msgtext, excel_list)

    if result:
        logfile.write('Sent SRE to excel email failed : ' + str(datetime.datetime.now()) + '\n\n')
    else:
        logfile.write('Sent SRE to excel email successed : ' + str(datetime.datetime.now()) + '\n\n')
        for i in os.listdir(sredownloadpath):
            move_sre_excel(os.path.join(sredownloadpath, i), os.path.join(srecompletepath, i))
        for i in os.listdir(sreexportpath):
            move_sre_excel(os.path.join(sreexportpath, i), os.path.join(srecompletepath, i))

    logfile.write('=== Transfer SRE to excel end :' + str(datetime.datetime.now()) + '\n\n')
    logfile.close()