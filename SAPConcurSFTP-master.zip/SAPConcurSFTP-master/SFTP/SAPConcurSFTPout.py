#!/usr/bin/python
# coding=UTF-8
# SAPConcurSFTPout.py               #
# SAP Concur SFTP out --> SAP ERP   #
# Create by 2021.10.04              #
# Author : James Hsiao              #
#####################################
import datetime
import gnupg
import paramiko
import configparser
import os
import os.path

config = configparser.ConfigParser()
config.read('config.ini', encoding='utf-8')

host = config['SFTP']['host']
port = config['SFTP']['port']
user = config['SFTP']['user']
privKey = paramiko.RSAKey.from_private_key_file(config['SFTP']['privKey'], config['SFTP']['passphrase'])
gpg_bin = config['PGP']['gpg_bin']
pppseckey = config['PGP']['pppseckey']
localoutpath = config['PATHS']['local_out_tmp']
localoutdecyptpath = config['PATHS']['local_out_path']
logpath = config['PATHS']['log_path']
remoteoutpath = config['PATHS']['remote_out_path']
saedownloadpath = config['DOWNLOAD_PATHS']['SAE_Download_path']
praedownloadpath = config['DOWNLOAD_PATHS']['PRAE_Download_path']
sredownloadpath = config['DOWNLOAD_PATHS']['SRE_Download_path']
archivepath = config['DOWNLOAD_PATHS']['ARCHIVE_path']

def connect_concur(logfile, hostname, port, username, pkey):
    try:
        conn = paramiko.SSHClient()
        conn.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        logfile.write('SAP Concur SFTP connecting to ' + hostname + '\n')
        conn.connect(hostname=hostname, port=port, username=username, pkey=pkey, allow_agent=True, disabled_algorithms=dict(pubkeys=['rsa-sha2-256', 'rsa-sha2-512']))
        logfile.write('SAP Concur SFTP connected.\n')
        return conn
    except Exception as e:
        logfile.write('Connect unexpected error :'+ str(e) +'\n')

def disconnect_concur(logfile, conn):
    try:
        conn.close()
        logfile.write('SAP Concur SFTP closed.\n')
    except Exception as e:
        logfile.write('Disconnect unexpected error :'+ str(e) + '\n')

def get_concur_files(logfile, conn):
    try:
        trans = paramiko.SFTPClient.from_transport(conn.get_transport())
        for i in trans.listdir(remoteoutpath):
            if i is not None:
                remotefile = '/out/'+i
                localfile = localoutpath+i
                trans.get(remotefile, localfile)
                trans.remove(remotefile)
                logfile.write('get file : ' + str(i) +'\n')
    except Exception as e:
        logfile.write('Get ftp file unexpected error :'+ str(e) + '\n')

def gpg_load_key():
    gpg = gnupg.GPG(gpgbinary=gpg_bin)
    gpg.encoding = 'utf-8'
    seckey = open(pppseckey).read()
    result = gpg.import_keys(seckey)
    return gpg

def gpg_decrpty_files(gpg, outpath, decyptpath):
    results = {}
    for i in os.listdir(outpath):
        with open(outpath+i, 'rb') as f:
            decyptfile = i.split('.')[0] + '.' + i.split('.')[1]
            status = gpg.decrypt_file(f, passphrase='mitutoyotw', output=decyptpath + decyptfile)
            results[(decyptfile)] = status.status
        if results[(decyptfile)] == 'decryption ok':
            os.remove(outpath+i)
    return results

def check_category(files):
    results = {}
    for key, result in files.items():
        if result == 'decryption ok':
            if 'SAE' in key:
                results[key] = 'SAE'
            elif 'travel' in key:
                results[key] = 'SRE'
            elif 'payment' in key:
                results[key] = 'PRAE'
            else :
                results[key] = 'ARCHIVE'
    return results

def move_categorised_files(files_dict):
    try:
        for key, result in files_dict.items():
            src = localoutdecyptpath + key
            if result == 'SAE':
                # dst = saedownloadpath + '\\' + key
                dst = os.path.join(saedownloadpath, key)
                logfile.write('move file from :' + src + ' to ' + dst + '\n')
                os.rename(src, dst)
            if result == 'SRE':
                # dst = sredownloadpath + '\\' + key
                dst = os.path.join(sredownloadpath, key)
                logfile.write('move file from :' + src + ' to ' + dst + '\n')
                os.rename(src, dst)
            if result == 'PRAE':
                # dst = praedownloadpath + '\\' + key
                dst = os.path.join(praedownloadpath, key)
                logfile.write('move file from :' + src + ' to ' + dst + '\n')
                os.rename(src, dst)
            if result == 'ARCHIVE':
                # dst = archivepath + '\\' + key
                dst = os.path.join(archivepath, key)
                logfile.write('move file from :' + src + ' to ' + dst + '\n')
                os.rename(src, dst)
    except Exception as e:
        logfile.write('remove file error :' + str(e) + '\n')


if True:
    # sftp -o IdentityFile=MTW-ConcurSSHRSAPrivkey.ppk p0021113gdod@mft-us.concursolutions.com

    # write logs
    logfile = open(logpath+'logs_'+ str(datetime.date.today())+'.txt', 'a')
    logfile.write('=== SFTP out === \n')
    logfile.write('SAP Concur SFTP start :' + str(datetime.datetime.now()) + '\n')

    # connect to Concur SFTP and fetch out files
    conn = connect_concur(logfile, host, port, user, privKey)
    get_concur_files(logfile, conn)
    disconnect_concur(logfile, conn)

    # decrpty files
    gpg = gpg_load_key()
    results = gpg_decrpty_files(gpg, localoutpath, localoutdecyptpath)
    i = 0
    for key, result in results.items():
        i = i + 1
        logfile.write(str(i) + ',' + key + ',' + result + '\n')

    # categorise files and move to specific folder
    files_dict = check_category(results)
    move_categorised_files(files_dict)

    logfile.write('SAP Concur SFTP end :' + str(datetime.datetime.now()) + '\n\n')
    logfile.close()